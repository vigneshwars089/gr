//30434
		var jqel = cviz.jQuery(':hover').last();
			var obj = jqel[0].__data__;
			var keyName ="root";
			console.log(obj.parent.children["0"].children["0"].children["0"].children["0"].children["0"]);
			/*if(obj.depth == 0){
				keyName = "All Records";
			}else{
				keyName = dataKeys[(obj.depth)-1];
			}*/
			//console.log(obj)
			//console.log(event)
			
			
			window.addEventListener("mousedown",function(){
			/*var jqel = cviz.jQuery(':hover').last();
			var obj = jqel[0].__data__;
			console.log(obj);
			var keyName ="root";
			if(obj.depth == 0){
				keyName = "root";
			}else{
				keyName = dataKeys[(obj.depth)-1];
			}
			console.log("keyName:"+keyName);*/
	
			/*console.log("x:"+obj.x);
			console.log("y:"+obj.y);
			console.log("dx:"+obj.dx)
			console.log("dy:"+obj.dy)
			console.log("key:"+obj.key);*/
			/*var arr = (d3.keys(obj));
			console.log(arr);
			var arrn= d3.entries(obj);
			console.log(arrn);
			var keys = d3.map(obj).keys();
			console.log(keys);*/
	})
	
			var jqel = cviz.jQuery(':hover').last();
			var obj = jqel[0].__data__;
			var keyName ="root";
			console.log(obj.parent.children["0"].children["0"].children["0"].children["0"].children["0"]);
			/*if(obj.depth == 0){
				keyName = "All Records";
			}else{
				keyName = dataKeys[(obj.depth)-1];
			}*/
			//console.log(obj)
			//console.log(event)