﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using graph2.Models;

namespace graph2.Controllers
{
    public class newController : Controller
    {
        //
        // GET: /new/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetData()
        {
            gClass1 p = new gClass1();
            List<gClass1> Li = new List<gClass1>();

            Li = p.GetData();
            ViewBag.details = Li;
            //  ViewData["gClass1"] = Li;
            return View();
        }

    }
}
