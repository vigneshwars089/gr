﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace graph2.Models
{
    public class gClass1
    {
        SqlConnection con = new SqlConnection();
        List<gClass1> applist = new List<gClass1>();
        public String app { get; set; }
        public Int32 user { get; set; }

        gClass1 p = null;
        public List<gClass1> GetData()
        {

            con.ConnectionString = "Data Source=PC348892;Initial Catalog=AccessDatabase;Integrated Security=True";

            con.Open();

            using (con)
            {

                SqlCommand cmd = new SqlCommand("select t2.ApplicationName,COUNT(t1.ApplicationID) AS num from dbo.Application as t2 inner join dbo.AccessDetails as t1  on t1.ApplicationID=t2.ApplicationID group by t2.ApplicationName", con);
                //SqlCommand cmd = new SqlCommand("SELECT ApplicationID, COUNT(*) AS num FROM dbo.AccessDetails GROUP BY  ApplicationID", con);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {

                    p = new gClass1();
                    p.app = Convert.ToString(rd.GetSqlValue(0));

                    p.user = Convert.ToInt32(rd.GetInt32(1));
                    applist.Add(p);

                }
            }
            return applist;
        }
    }
}